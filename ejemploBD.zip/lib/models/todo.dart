class Todo {
  int? id;
  String content;
  String title;
  static const String TABLENAME = "todos";

  Todo({this.id, required this.content, required this.title});

  Map<String, dynamic> toMap() {
    return {'id': id, 'content': content, 'title': title};
  }
}
