import 'package:flutter/material.dart';
import 'package:flutter_db2/pages/page2.dart';

class ReadTodoButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: () {
        _navigateToReadTodoScreen(context);
      },
      child: Text("Leer Tareas"),
    );
  }

  _navigateToReadTodoScreen(BuildContext context) async {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => Page2()),
    );
  }
}
