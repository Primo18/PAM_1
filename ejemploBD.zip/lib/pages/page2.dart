import 'package:flutter/material.dart';
import 'package:flutter_db2/pages/page1.dart';

import '../database_helper.dart';
import '../models/todo.dart';

class Page2 extends StatefulWidget {
  Page2({Key? key}) : super(key: key);

  @override
  State<Page2> createState() => _Page2State();
}

class _Page2State extends State<Page2> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Listado Tareas'),
      ),
      body: FutureBuilder<List<Todo>>(
        future: DatabaseHelper.instance.retrieveTodos(),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
              itemCount: snapshot.data?.length,
              itemBuilder: (BuildContext context, int index) {
                return ListTile(
                  title: Text(snapshot.data![index].title),
                  leading: Text(snapshot.data![index].id.toString()),
                  subtitle: Text(snapshot.data![index].content),
                  onTap: () =>
                      _navigateToDetail(context, snapshot.data![index]),
                  trailing: IconButton(
                      alignment: Alignment.center,
                      icon: const Icon(Icons.delete),
                      onPressed: () async {
                        _deleteTodo(snapshot.data![index]);
                        setState(() {});
                      }),
                );
              },
            );
          } else if (snapshot.hasError) {
            return Text("Oops!");
          }
          return Center(child: CircularProgressIndicator());
        },
      ),
    );
  }
}

_deleteTodo(Todo todo) {
  DatabaseHelper.instance.deleteTodo(todo.id!);
}

_navigateToDetail(BuildContext context, Todo todo) async {
  Navigator.push(
    context,
    MaterialPageRoute(builder: (context) => Page1(todo: todo)),
  );
}
